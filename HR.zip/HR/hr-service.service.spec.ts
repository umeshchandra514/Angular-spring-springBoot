import { TestBed } from '@angular/core/testing';

import { HrServiceService } from './hr-service.service';

describe('HrServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: HrServiceService = TestBed.get(HrServiceService);
    expect(service).toBeTruthy();
  });
});
