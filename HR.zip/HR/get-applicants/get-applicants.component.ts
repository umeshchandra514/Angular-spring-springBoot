import { Component, OnInit } from '@angular/core';
import { HrServiceService } from '../hr-service.service';
import { NotificationService } from 'src/app/services/notification.service';
import { ApplicationForm } from '../../application-form/application-form';

@Component({
  selector: 'app-get-applicants',
  templateUrl: './get-applicants.component.html',
  styleUrls: ['./get-applicants.component.css']
})
export class GetApplicantsComponent implements OnInit {

  applicants:ApplicationForm[]
  showData:boolean
  constructor(private _HrService:HrServiceService,
    private _notification:NotificationService) { }

  ngOnInit() {
    this.getApplicants()
  }

  getApplicants(){
    this._HrService.getApplicants().subscribe(data =>{
      if(data.body.length == 0){  
        this.showData = false
        console.log("sdf")
      }
      else{
        this.applicants = data.body
        this.showData = true
      }
    })
  }

  //shortListStatus, 1=> shortListed , 2 = Rejected 
  isShortlist(applicantId,shortListStatus){
      this._HrService.shortListApplicants(parseInt(applicantId),parseInt(shortListStatus)).subscribe(data =>{
            this.getApplicants()
            this._HrService.shortListed()
            this._HrService.rejected()
      })
  }



}
