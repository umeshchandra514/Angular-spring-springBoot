import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { ApplicationForm } from '../application-form/application-form';
import { Observable } from 'rxjs';
import { EmployeeDetails } from './schedule-dialog/employee';
import { InterviewDetails } from './schedule-dialog/interview';
import { StatusDetails } from './request-interview-status/status-details';

@Injectable({
  providedIn: 'root'
})
export class HrServiceService {

  Get_Applicant_Url = "http://localhost:8080/form"
  showSchedule:boolean = true

  constructor(private _http:HttpClient) { }

  //Observable to get the fresh applicants
  getApplicants():Observable<HttpResponse<ApplicationForm[]>>{
    return this._http.get<ApplicationForm[]>(this.Get_Applicant_Url,{observe:'response'})
  }

  //Hr will may Shortlist/Reject the Applicants
  shortListApplicants(applicantId:number,isShortlisted:number):Observable<HttpResponse<Boolean>>
  {
    let ShortList_Url = "http://localhost:8080/shortlist/"+applicantId+"/"+isShortlisted
    return this._http.get<Boolean>(ShortList_Url,{observe:'response'})
  }

  //Status refers to shortlisted/rejected------
  noShortlists:string
  noRejections:string
  ShortListedApplicationForm:ApplicationForm
  ShortListedApplicationForm1:ApplicationForm
  RejectedApplicationForm:ApplicationForm
  RejectedApplicationForm1:ApplicationForm
  getApplicantsbyStatus(status:number):Observable<HttpResponse<ApplicationForm>>{
    let Url = "http://localhost:8080/getshortlist/"+status

    return this._http.get<ApplicationForm>(Url,{observe: 'response'})
  }
  shortListed(){
    this.getApplicantsbyStatus(1).subscribe(data => {
        if(data.status == 204){
            this.noShortlists = "No Applicants were Shortlisted" 
        }
        else if(data.status == 200){
          this.ShortListedApplicationForm1= data.body
          this.ShortListedApplicationForm = this.ShortListedApplicationForm1
          this.noShortlists =""
        }
    })
  }
  rejected(){
    this.getApplicantsbyStatus(2).subscribe(data => {
        if(data.status == 204){
            this.noRejections = "No Rejections found" 
        }
        else if(data.status == 200){
            console.log(data.body)
            this.RejectedApplicationForm1 = data.body
            this.RejectedApplicationForm = this.RejectedApplicationForm1
            this.noRejections = ""
        }
    })
  }
  //-----------------------


  //getting an employye when clicking Add button in dialog
  getEmployeeName(employeeId:number):Observable<HttpResponse<EmployeeDetails>>{
    let URL:string ="http://localhost:8080/getEmployee/"+employeeId  
    return this._http.get<EmployeeDetails>(URL,{observe:'response'})
  }


  //scheduling Interview by HR
  schedule(interviewDetails:InterviewDetails,applicantId:number,employeeId:number){
      let URL = "http://localhost:8080/schedule/"+applicantId+"/"+employeeId
      return this._http.post(URL,interviewDetails,{observe:'response'})
  }


  //
  scheduleStatus(availability:number):Observable<HttpResponse<StatusDetails>>{
    let URL = "http://localhost:8080/getSchedule/"+availability
    return this._http.get<StatusDetails>(URL,{observe:'response'})
  }

}
