import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RequestInterviewStatusComponent } from './request-interview-status.component';

describe('RequestInterviewStatusComponent', () => {
  let component: RequestInterviewStatusComponent;
  let fixture: ComponentFixture<RequestInterviewStatusComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RequestInterviewStatusComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RequestInterviewStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
