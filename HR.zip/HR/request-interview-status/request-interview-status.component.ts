import { Component, OnInit } from '@angular/core';
import { MainService } from '../../Employee/main.service';
import { HrServiceService } from '../hr-service.service';
import { StatusDetails } from './status-details';

@Component({
  selector: 'app-request-interview-status',
  templateUrl: './request-interview-status.component.html',
  styleUrls: ['./request-interview-status.component.css']
})
export class RequestInterviewStatusComponent implements OnInit {

  details:StatusDetails
  details1:StatusDetails
  constructor(private _HrService:HrServiceService) { }

  ngOnInit() {
    this.acceptedStatuses()
  }

  acceptedStatuses(){
        this._HrService.scheduleStatus(1).subscribe(data =>{
            this.details1 = data.body
            this.details = this.details1
        })    
  }

  rejectedStatuses(){
        this._HrService.scheduleStatus(2).subscribe()    
  }

}
