export class StatusDetails{
    constructor(private employeeName:string,private applicantName:string
        ,private applicantJobRole:string,private interviewEmpId:string){

    }
}

