export interface Details{

    employeeId:number;
    employeeName:String;
    applicantName:string;
}