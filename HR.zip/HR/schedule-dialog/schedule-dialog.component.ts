import { Component, OnInit } from '@angular/core';
import { ApplicationForm } from '../../application-form/application-form';
import { HrServiceService } from '../hr-service.service';
import { EmployeeDetails } from './employee';
import { Details } from './customDetails';
import { NotificationService } from 'src/app/services/notification.service';
import { InterviewDetails } from './interview';

@Component({
  selector: 'app-schedule-dialog',
  templateUrl: './schedule-dialog.component.html',
  styleUrls: ['./schedule-dialog.component.css']
})
export class ScheduleDialogComponent implements OnInit {

  data:ApplicationForm
  employee:EmployeeDetails
  details:Details = {employeeId: 0, employeeName:'', applicantName: ''}
  noContent:boolean = false
  unableToSchedule:string =""
  applicantName:string
  applicantId:number
  employeeId:number 
  minDate:Date = new Date();

  constructor(private _HrService:HrServiceService,
    private _notification:NotificationService) { }

  ngOnInit() {
    this.applicantName= JSON.parse(JSON.stringify(this.data)).applicantName
    this.applicantId= JSON.parse(JSON.stringify(this.data)).applicantId

  }

  schedule(date){
    let interviewDetails:InterviewDetails  =  new InterviewDetails(new Date(date))
    this._HrService.schedule(interviewDetails,this.applicantId,this.employeeId).subscribe(data => {
      if(data.status == 204)
      {
          this.unableToSchedule = "Applicant/Employee Not found"
      }
      else{
          this._notification.success("Scheduled, Waiting for Employee's Reponse")
      }
    })
  }

  employeeDetails(employeeId:number){
      this._HrService.getEmployeeName(employeeId).subscribe(data =>{
          if(data.status == 204){
            this.noContent=true
          }
          else if(data.status == 200){
              this.employee = data.body
              this.details.employeeId =employeeId
              this.details.employeeName = JSON.parse(JSON.stringify(this.employee)).employeeName
              this.noContent=false
              
          }
          this.employeeId = employeeId
      })
      
      
  }



}
