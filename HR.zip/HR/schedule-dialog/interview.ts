export class InterviewDetails{
    constructor(
        private dateOfInterview:Date
    ){}
}