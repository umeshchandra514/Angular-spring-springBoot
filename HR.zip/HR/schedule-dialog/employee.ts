export class EmployeeDetails{
    constructor(
        private employeeName:String
    ){

    }
}