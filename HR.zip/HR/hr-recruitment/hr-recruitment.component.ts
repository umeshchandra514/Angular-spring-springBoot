import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hr-recruitment',
  templateUrl: './hr-recruitment.component.html',
  styleUrls: ['./hr-recruitment.component.css']
})
export class HRRecruitmentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
