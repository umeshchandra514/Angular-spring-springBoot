import { Component, OnInit } from '@angular/core';
import { HrServiceService } from '../hr-service.service';
import { MatDialogConfig, MatDialog } from '@angular/material';
import { ScheduleDialogComponent } from '../schedule-dialog/schedule-dialog.component';

@Component({
  selector: 'app-shortlisted-rejected',
  templateUrl: './shortlisted-rejected.component.html',
  styleUrls: ['./shortlisted-rejected.component.css']
})
export class ShortlistedRejectedComponent implements OnInit {

  
  constructor(private _HrService:HrServiceService,
      private _dialog:MatDialog) { }

  ngOnInit() {
    this._HrService.shortListed()
    this._HrService.rejected()
  }

  openDialog(data){    
    //let property:AddProperty = this.Mapping(data)
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = false;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "60%";
    let dialog = this._dialog.open(ScheduleDialogComponent, dialogConfig);//PropertyDialogComponent
   dialog.componentInstance.data = data 
  }




}
