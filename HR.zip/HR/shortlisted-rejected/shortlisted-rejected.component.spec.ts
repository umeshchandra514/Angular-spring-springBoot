import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShortlistedRejectedComponent } from './shortlisted-rejected.component';

describe('ShortlistedRejectedComponent', () => {
  let component: ShortlistedRejectedComponent;
  let fixture: ComponentFixture<ShortlistedRejectedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShortlistedRejectedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShortlistedRejectedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
