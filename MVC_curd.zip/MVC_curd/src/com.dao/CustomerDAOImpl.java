package com.dao;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import com.model.CustomerDetails;
import com.model.CustomerDetailsMapper;

public class CustomerDAOImpl extends JdbcDaoSupport implements CustomerDAO {


	
	String ADD_CUSTOMER="insert into customerdb.customer(customerId,customerFullName,email,mobile,city,gender,customerType,billDate,isActive) values(?,?,?,?,?,?,?,?,?)";
	
	final String UPDATE_CUSTOMER=
			"update customer set customerFullName=?,email=?,mobile=?,city=?,gender=?,customerType=?,billDate=?,isActive=? where customerId= ?";
	final String DELETE_CUSTOMER=
			" delete from customer where customerId=?";
	
	final String FIND_CUSTOMER
			="select * from customer where customerId=?";

	final String EXIST_CUSTOMER
	="select count(*) from customer where customerId=?";
	
	final String ALL_CUSTOMERS
		="SELECT * from customer";
	
/*	JdbcTemplate jdbcTemplate;
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
*/
	@Override
	public boolean addCustomer(CustomerDetails customer) {
	
		/*return (jdbcTemplate.update(ADD_CUSTOMER,customer.getCustomerId(),
				customer.getCustomerFullName(),
				customer.getCustomerType(),
				customer.getCity(),
				customer.getMobile(),
				customer.getGender(),
				customer.getEmail(),
				customer.getBillDate(),
				customer.getIsActive()))>0;
*/
		
		return (getJdbcTemplate().update(ADD_CUSTOMER, new PreparedStatementSetter() {
			
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setInt(1, customer.getCustomerId());
				ps.setString(2, customer.getCustomerFullName());
				ps.setString(3, customer.getCustomerType());
				ps.setString(4, customer.getCity());
				ps.setString(5, customer.getMobile());
				ps.setString(6, customer.getGender());
				ps.setString(7, customer.getEmail());
				ps.setDate(8, customer.getBillDate()==null ? new Date(1900,00,00) : convertDate(customer.getBillDate()));
				ps.setBoolean(9,customer.getIsActive()==null ? false : customer.getIsActive());//
				
				
			}
		})
				)>0;
		
		
		
	}
	
	public Date convertDate(java.util.Date Date)
	{
		if(Date!=null){
			java.sql.Date sDate= new java.sql.Date(Date.getTime());
			return sDate;
		}

		else
			return null;
		
		
	}

	@Override
	public boolean updateCustomer(CustomerDetails customer) {
	 	
			return getJdbcTemplate().update(UPDATE_CUSTOMER, new PreparedStatementSetter() {
				CustomerDetails oldCustomer = findCustomer(customer.getCustomerId());
				
				//merge(customer,oldCustomer);
				
				@Override
				public void setValues(PreparedStatement ps) throws SQLException {
					ps.setInt(9, customer.getCustomerId());
					ps.setString(1, customer.getCustomerFullName()==null ? oldCustomer.getCustomerFullName() : customer.getCustomerFullName());
					ps.setString(2, customer.getCustomerType()==null ? oldCustomer.getCustomerType() : customer.getCustomerType());
					ps.setString(3, customer.getCity()==null ? oldCustomer.getCity() : customer.getCity());
					ps.setString(4, customer.getMobile()==null ? oldCustomer.getMobile() : customer.getMobile());
					ps.setString(5, customer.getGender()==null ? oldCustomer.getGender() : customer.getGender());
					ps.setString(6, customer.getEmail()==null ? oldCustomer.getEmail() : customer.getEmail());
					ps.setDate(7,customer.getBillDate()==null ? convertDate(oldCustomer.getBillDate()) : convertDate(customer.getBillDate()));//convertDate(customer.getBillDate())
					ps.setBoolean(8, customer.getIsActive()==null ? oldCustomer.getIsActive() : customer.getIsActive());//
					
					
				}
			})>0;
		
				
		
	}
	
	
	

	@Override
	public boolean deleteCustomer(int customerId) {
		//return  false;
	return (getJdbcTemplate().update(DELETE_CUSTOMER,customerId))>0 ;
	
	}

	@Override
	public CustomerDetails findCustomer(int customerId) {
		
		return getJdbcTemplate().queryForObject(FIND_CUSTOMER ,new CustomerDetailsMapper(),new Object[] {customerId}  );
		
	}

	@Override
	public boolean isCustomerExists(int customerId) {
		// TODO Auto-generated method stub
		 //return getJdbcTemplate().queryForObject(EXIST_CUSTOMER,new Object[] {customerId} , Integer.class)>0;
		 return getJdbcTemplate().queryForInt(EXIST_CUSTOMER, new Object[] {customerId})>0;
		
		//System.out.println(getJdbcTemplate().queryForList(EXIST_CUSTOMER, new Object[] {customerId}, Integer.class));
		//return false;
	}

	@Override
	public List<CustomerDetails> getCustomers() {
		// TODO Auto-generated method stub
		return getJdbcTemplate().query(ALL_CUSTOMERS, new CustomerDetailsMapper());
		
	}

}
