package com.propertyeditors;

import java.beans.PropertyEditorSupport;

public class CustomIdEditor extends PropertyEditorSupport{
	
	@Override
	public void setAsText(String id)
	{
		System.out.println(id);
		if(id.equals(""))
		{
			System.out.println("entered");
			setValue(0);
		}
		else
		{
			setValue(Integer.valueOf(id));
		}
		
	}

}
