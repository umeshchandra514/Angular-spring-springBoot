package com.controller;


import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.model.CustomerDetails;
import com.service.CustomerService;

@Controller
public class MyController {

	
	
	
	
	

	
	@RequestMapping("insert")
	public String doINsert(){
		//System.out.println("sss");
		return "insert";
	}
	
	@RequestMapping("/update")
	public String update(){
		return "update";
	}
	@RequestMapping("/delete")
	public String delete(){
		return "delete";
	}
	
	@RequestMapping("/student/{id}")
	public ModelAndView student(@PathVariable("id")Integer id)
	{
		ModelAndView view = new ModelAndView();
		view.setViewName("student");
	//	Object modelMap;
		//view.addObject(modelMap)
		
		view.addObject("id", id);
	    view.addObject("anchor","/MVC_curd/delete.do");	
		return view;
		
	}
	
}
