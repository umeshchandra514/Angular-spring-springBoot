package com.controller;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomNumberEditor;
import org.springframework.beans.propertyeditors.CustomBooleanEditor;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.model.CustomerDetails;
import com.propertyeditors.CustomIdEditor;
import com.service.CustomerService;
import java.util.List;

@Controller
public class FormController {

	@InitBinder
	public void initbinder(WebDataBinder binder)
	{
		
		CustomDateEditor editor= new CustomDateEditor(new SimpleDateFormat("yyyy-mm-dd"),true);
	//	binder.registerCustomEditor(Boolean.class, new CustomBooleanEditor(true));
	//	binder.registerCustomEditor(String.class, new CustomNumberEditor(Integer.class, true));
		binder.registerCustomEditor(Date.class, editor);
		binder.registerCustomEditor(Integer.class,"customerId",new CustomIdEditor());
		System.out.println("ssssssss");
		
	}
	
	@Autowired
	CustomerService customerService;
	
	
	@RequestMapping("form")
	public ModelAndView doform(CustomerDetails customer){
		
		ModelAndView view = new ModelAndView();
		view.setViewName("form");
		
		if(!customerService.isCustomerExists(customer.getCustomerId()))
		{
			customerService.addCustomer(customer);
			view.addObject("customer","Customer Added");
		}
		else
		{
			view.addObject("customer","Customer with id:"+customer.getCustomerId()+"already exits");
		}
			
		return view;
	}
	
	
	@RequestMapping("formdelete")
	public ModelAndView doDelete(CustomerDetails customer)
	{
		ModelAndView view = new ModelAndView();
		view.setViewName("form");
		//System.out.println(customer.getCustomerId());
		if(customer.getCustomerId()>0)
		{
			if(customerService.isCustomerExists(customer.getCustomerId()))
			{
				if(customerService.deleteCustomer(customer.getCustomerId()))
					view.addObject("customer","Customer Deleted");
				else
					view.addObject("customer","Unable to Delete");
			}
			else
			{
				view.addObject("customer","Customer Not Available");
			}
		}
		else
		{
			view.addObject("customer","Please provide CustomerId fro Deleting ");
		}
		
		return view;
	}
	
	
	
	@RequestMapping("formupdate")
	public ModelAndView doUpdate(CustomerDetails customer)
	{
		ModelAndView view = new ModelAndView();
		view.setViewName("form");
		
		if(customer.getCustomerId()>0)
		{
			if(customerService.isCustomerExists(customer.getCustomerId()))
			{
				customerService.updateCustomer(customer);
				view.addObject("customer", "Updated");
			}
			else
			{
				view.addObject("customer", "Customer with id:"+customer.getCustomerId()+" doesn't exist");
			}
		
		}
		else
		{
			view.addObject("customer","Please provide CustomerId fro Deleting ");
		}
		return view;
	}
	

	@RequestMapping("allrecords")
	public ModelAndView doAll()
	{
		ModelAndView view = new ModelAndView();
		view.setViewName("form");
		
		List<CustomerDetails> customer=customerService.getCustomers();
		if(customer!=null)
			view.addObject("customer",customer);
		else
			view.addObject("customer","No records found");
		return view;
	}
	
	
	
	@RequestMapping("record")
	public ModelAndView doRecord(CustomerDetails customer)
	{
		ModelAndView view = new ModelAndView();
		view.setViewName("form");
		if(customerService.isCustomerExists(customer.getCustomerId()))
		{
		  customer= customerService.findCustomer(customer.getCustomerId());
		  view.addObject("customer",customer);
		}
		else
		{
			view.addObject("customer","Customer Doesn't exist");
		}
		
		return view;
	}
	
	@RequestMapping("exist")
	public ModelAndView doExist(CustomerDetails customer)
	{
		ModelAndView view = new ModelAndView();
		view.setViewName("form");
		
		if(customerService.isCustomerExists(customer.getCustomerId()))
		{
			view.addObject("customer","Customer exists with id:"+customer.getCustomerId());
		}
		else
		{
			view.addObject("customer","Customer Doesn't exist");
		}
		
		return view;
	}
	
	

}
