package com.acheron.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.acheron.model.repository.ApplicantForm;



public interface RecruitmentFormRepository extends CrudRepository<ApplicantForm, Integer> {
	List<ApplicantForm> findByIsShortlisted(Integer isshortlisted);
	
	
}
