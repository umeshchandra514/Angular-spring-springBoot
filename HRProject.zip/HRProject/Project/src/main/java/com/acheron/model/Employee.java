package com.acheron.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Employee")
public class Employee {
	
	@Id
	private int employeeId;
	private String employeeName;
	private String jobRole;
	private String phoneNumber;
	private int compensatoryDays;
	private int leavesApplied;
	
	

	public Employee() {
		// TODO Auto-generated constructor stub
	}

	
	public Employee(int employeeId, String employeeName, String jobRole, String phoneNumber, int compensatoryDays,
			int leavesApplied) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.jobRole = jobRole;
		this.phoneNumber = phoneNumber;
		this.compensatoryDays = compensatoryDays;
		this.leavesApplied = leavesApplied;
	}


	public int getEmployeeId() {
		return employeeId;
	}


	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}


	public String getEmployeeName() {
		return employeeName;
	}


	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}


	public String getJobRole() {
		return jobRole;
	}


	public void setJobRole(String jobRole) {
		this.jobRole = jobRole;
	}


	public String getPhoneNumber() {
		return phoneNumber;
	}


	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}


	public int getCompensatoryDays() {
		return compensatoryDays;
	}


	public void setCompensatoryDays(int compensatoryDays) {
		this.compensatoryDays = compensatoryDays;
	}


	public int getLeavesApplied() {
		return leavesApplied;
	}


	public void setLeavesApplied(int leavesApplied) {
		this.leavesApplied = leavesApplied;
	}


	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", jobRole=" + jobRole
				+ ", phoneNumber=" + phoneNumber + ", compensatoryDays=" + compensatoryDays + ", leavesApplied="
				+ leavesApplied + "]";
	}


	
	


}