package com.acheron.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.acheron.model.Employee;
import com.acheron.model.EmployeeView;
@Repository
public interface EmployeeRepository extends CrudRepository<Employee,Integer> {
	EmployeeView findEmployeeNameByEmployeeId(Integer employeeId);
}
