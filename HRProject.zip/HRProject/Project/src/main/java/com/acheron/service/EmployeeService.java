package com.acheron.service;

import java.util.List;
import java.util.Optional;

import com.acheron.model.Employee;
import com.acheron.model.EmployeeView;

public interface EmployeeService {
	public  List<Employee> getEmployees();
	public 	Employee addEmployee(Employee employee);
	public 	Optional<Employee> getEmployee(int employeeId);
	EmployeeView getEmployeeName(Integer employeeId);
	
}
