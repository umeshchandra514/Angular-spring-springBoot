package com.acheron.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.acheron.model.repository.EmployeeScheduleView;
import com.acheron.model.Employee;
import com.acheron.model.EmployeeView;
import com.acheron.model.repository.ApplicantForm;
import com.acheron.model.repository.Interview;
import com.acheron.model.repository.InterviewView;
import com.acheron.repository.EmployeeRepository;
import com.acheron.service.EmployeeService;
import com.acheron.service.RecruitmentService;

@RestController
@CrossOrigin( origins = "*")
public class RecruitmentController {

	
	@Autowired
	RecruitmentService recruitmentService;
	
	
	@Autowired
	EmployeeService employeeService;
	
	
	//Adding Applicant
	@SuppressWarnings("rawtypes")
	@PostMapping("/form")
	public ResponseEntity setApplicant(@RequestBody ApplicantForm recruitmentApplicantForm) {
		
		HttpStatus httpStatus;
		if(recruitmentService.addApplicant(recruitmentApplicantForm) != null) {
			httpStatus=HttpStatus.OK;
		}
		else
		{
			httpStatus=HttpStatus.CONFLICT;
		}
		return new ResponseEntity(httpStatus);
	}
	
	
	
	// For HR, the applied candidate's details will be displayed 
	@GetMapping("/form")
	public ResponseEntity<List<ApplicantForm>> getApplicants() {
		
		HttpStatus httpStatus;
		List<ApplicantForm> allApplicants = recruitmentService.getApplicants();
		if(allApplicants != null) {
			httpStatus = HttpStatus.OK;
		}
		else
		{
			httpStatus = HttpStatus.NO_CONTENT;
		}
		return new ResponseEntity<List<ApplicantForm>>(allApplicants,httpStatus);
	}
	

	
	//-------ShortList-------
	
	
	//HR will shortlist based on requirements
	@SuppressWarnings("rawtypes")
	@GetMapping("/shortlist/{applicantId}/{isShortlisted}")
	public ResponseEntity shortListApplicant(@PathVariable("applicantId") String applicantId,@PathVariable("isShortlisted") String isShortlisted)
	{
			Optional<ApplicantForm> form = recruitmentService.getApplicantById(Integer.parseInt(applicantId));
			HttpStatus httpStatus;
			
			if(form.isPresent()) {
				form.get().setIsShortlisted(Integer.parseInt(isShortlisted));
				recruitmentService.addApplicant(form.get());
				httpStatus = HttpStatus.OK;
			}
			else
			{
				httpStatus = HttpStatus.CONFLICT;
			}
			
			return new ResponseEntity(httpStatus);
	}
	
	
	// Retreving the applicant details based on isshortlisted
	@GetMapping("/getshortlist/{isShortlisted}")
	public ResponseEntity<List<ApplicantForm>> shortListed(@PathVariable("isShortlisted") String isShortlisted)
	{
			HttpStatus httpStatus;
			List<ApplicantForm> shortlist= recruitmentService.getshortlist(Integer.parseInt(isShortlisted));
			if( shortlist.size()!= 0) {
				httpStatus = HttpStatus.OK;
			}
			else
			{
				httpStatus = HttpStatus.NO_CONTENT;
			}
			
			return new ResponseEntity<List<ApplicantForm>>(shortlist,httpStatus);
	}
	
	
	
	//-------------Schedule Interview---------------
	
	
	
	//HR will schedule interview with particular EMPLOYEE
	@PostMapping("/schedule/{applicantId}/{employeeId}")
	public ResponseEntity schedule(@RequestBody Interview recruitmentInterview,@PathVariable("applicantId") String applicantId,@PathVariable("employeeId") String employeeId) {
		
		HttpStatus httpStatus;
		if(recruitmentService.scheduleInterview(recruitmentInterview,Integer.parseInt(applicantId),Integer.parseInt(employeeId)) != null) {
			httpStatus = HttpStatus.OK;
		}
		else
		{
			httpStatus = HttpStatus.NO_CONTENT;
		}
		return new ResponseEntity(httpStatus);
	}
	
	
	//Retreving Employee name from  employeeId
	@RequestMapping("/getEmployee/{employeeId}")
	public ResponseEntity<EmployeeView> getEmployeeName(@PathVariable("employeeId") String employeeId){
		
		EmployeeView employeeView = employeeService.getEmployeeName(Integer.parseInt(employeeId));
		HttpStatus httpStatus;
		if(employeeView != null) {
			httpStatus = HttpStatus.OK;
			
		}
		else
		{
			httpStatus = HttpStatus.NO_CONTENT;
		}
		
		return new ResponseEntity<EmployeeView>(employeeView,httpStatus);
	}
	
	
	//View interview details to EMPLOYEE , he/she may accept or reject to be in interview panel 
	@GetMapping("/schedule/{employeeId}")
	public ResponseEntity<List<InterviewView>> getSchedules(@PathVariable("employeeId") String employeeId) {
		
		
		List<InterviewView> details = recruitmentService.fetchByEmp(employeeService.getEmployee(Integer.parseInt(employeeId)).get());
		HttpStatus httpStatus ;
		if(details.size() ==  0) 
			httpStatus =  HttpStatus.NO_CONTENT;
		else
			httpStatus = HttpStatus.OK;
		
		return new ResponseEntity<List<InterviewView>>(details,httpStatus);

	}
	
	
	
	//Employee accpeting/rejecting to be in interview panel
	@PutMapping("/schedule/{interviewId}/{availability}")
	public ResponseEntity available(@PathVariable("availability") String availability,@PathVariable("interviewId") String interviewId) {
		
		Optional<Interview> recruitmentInterview = recruitmentService.find(Integer.parseInt(interviewId));
		HttpStatus httpStatus ;
		
		if(recruitmentInterview.isPresent()) {
			Interview interview = recruitmentInterview.get();
			interview.setAvailability(Integer.parseInt(availability));
			recruitmentService.scheduleInterview(interview,
					interview.getRecruitmentForm().getApplicantId(),interview.getEmployee().getEmployeeId());
			
			httpStatus = HttpStatus.OK;
		}
		else
		{
			httpStatus = HttpStatus.CONFLICT;
		}		
		
		return new ResponseEntity(httpStatus);
	}
	
	//HR will be able to see whether the employee is accepted/rejected to be in interview panel 
	@GetMapping("getSchedule/{availability}")
	public ResponseEntity<List<EmployeeScheduleView>> getInterviewStatus(@PathVariable("availability") String availability)
	{
		
		List<EmployeeScheduleView> schedules = recruitmentService.fetch(Integer.parseInt(availability));
		HttpStatus httpStatus ;
		
		if(schedules.size() != 0)
		{
			httpStatus = HttpStatus.OK;
		}
		else
		{
			httpStatus = HttpStatus.NO_CONTENT;
		}
		
		return new ResponseEntity<List<EmployeeScheduleView>>(schedules,httpStatus);
	}
	
}
