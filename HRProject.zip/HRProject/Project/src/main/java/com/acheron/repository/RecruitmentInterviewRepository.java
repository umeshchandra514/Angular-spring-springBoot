package com.acheron.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.acheron.model.Employee;
import com.acheron.model.repository.EmployeeScheduleView;
import com.acheron.model.repository.Interview;
import com.acheron.model.repository.InterviewView;



public interface RecruitmentInterviewRepository extends CrudRepository<Interview, Integer> {

	
	@Query(value="select e.employee_name,x.* from employee as e INNER JOIN (select a.applicant_name,a.applicant_job_role,employee_id,i.availability from recruitment_applicant_form as a INNER JOIN recruitment_interview as i where a.applicant_id = i.applicant_id AND i.availability = ?1) as x where e.employee_id = x.employee_id;",
				nativeQuery = true)
	List<EmployeeScheduleView> findEmployeeAvailability(Integer availability);

	
	
	@Query(value = "select * from (select employee_id,applicant_name,applicant_job_role,applicant_experience,date_of_interview,id from recruitment_applicant_form as a INNER JOIN recruitment_interview as i where a.applicant_id = i.applicant_id AND i.availability = 0) as custom where employee_id = ?1",nativeQuery=true)
	List<InterviewView> fetchDetailsByEmployee(Integer employeeId);
	
}

