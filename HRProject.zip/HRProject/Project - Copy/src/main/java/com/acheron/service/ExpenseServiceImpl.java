package com.acheron.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;

import com.acheron.model.Expense;
import com.acheron.repository.ExpenseRepository;

@Service
public class ExpenseServiceImpl implements ExpenseService{
	
	
	@Autowired
	ExpenseRepository expenseRepository;


	
	@Override
	public boolean addExpenses(Expense expense){
		expenseRepository.save(expense);
		
		return true;
	}


	@Override
	public List<Expense> getExpenses() {
			return (List<Expense>) expenseRepository.findAll();
	}
	
	
	@Override
	public List<Expense> getExpensesByStatus(Integer status){
		return expenseRepository.findByStatus(status);
	}

}
