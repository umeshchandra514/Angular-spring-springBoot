package com.acheron.repository;

import org.springframework.data.repository.CrudRepository;

import com.acheron.model.User;

public interface UserRepository extends CrudRepository<User, Integer> {
	
	User findByUserName(String username);
	String findUserRoleByUserName(String username);

}
