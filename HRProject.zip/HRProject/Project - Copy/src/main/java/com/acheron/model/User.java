package com.acheron.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class User {

	
	@Id
	private String userName;
	private String password;
	private String userDesignation;
	
	User(){
		
	}
	
	User(User user){
		
	}

	public User(String username, String password, String userDesignation) {
		super();
		this.userName = username;
		this.password = password;
		this.userDesignation = userDesignation;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String username) {
		this.userName = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUserDesignation() {
		return userDesignation;
	}

	public void setUserDesignation(String userDesignation) {
		this.userDesignation = userDesignation;
	}

	@Override
	public String toString() {
		return "User [username=" + userName + ", password=" + password + ", userDesignation=" + userDesignation + "]";
	}

		
	
	
}
