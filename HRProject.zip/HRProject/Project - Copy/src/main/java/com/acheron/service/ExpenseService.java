package com.acheron.service;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.acheron.model.Expense;



public interface ExpenseService {

	boolean addExpenses(Expense expense);

	List<Expense> getExpenses();

	List<Expense> getExpensesByStatus(Integer status);

}
