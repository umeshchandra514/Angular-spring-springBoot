package com.acheron.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Employee")
public class Employee {
	
	@Id
	private int employeeId;
	private String employeeName;
	private int compensatoryDays;
	private int leavesRemaining;

	public Employee() {
		// TODO Auto-generated constructor stub
	}

	public Employee(int employeeId, String employeeName, int compensatoryDays, int leavesRemaining) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.compensatoryDays = compensatoryDays;
		this.leavesRemaining = leavesRemaining;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public int getCompensatoryDays() {
		return compensatoryDays;
	}

	public void setCompensatoryDays(int compensatoryDays) {
		this.compensatoryDays = compensatoryDays;
	}

	public int getLeavesRemaining() {
		return leavesRemaining;
	}

	public void setLeavesRemaining(int leavesRemaining) {
		this.leavesRemaining = leavesRemaining;
	}

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", compensatoryDays="
				+ compensatoryDays + ", leavesRemaining=" + leavesRemaining + "]";
	}

	
	
	


}