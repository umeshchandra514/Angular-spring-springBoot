package com.acheron.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.acheron.model.FileDB;


@Repository
public interface FileRepository extends CrudRepository<FileDB, Integer>{
	
	@Query(value="select * from files where id = ?1",nativeQuery = true)
	public FileDB getById(String Id);
}
