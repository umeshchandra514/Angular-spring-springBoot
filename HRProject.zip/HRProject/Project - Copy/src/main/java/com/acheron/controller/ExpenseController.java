package com.acheron.controller;

import java.util.List;

import org.hibernate.annotations.GenericGenerators;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.acheron.model.Expense;
import com.acheron.service.ExpenseService;
import com.acheron.service.ExpenseServiceImpl;

@RestController
@CrossOrigin(origins = "*")
public class ExpenseController {

	
	@Autowired
	ExpenseService expenseService;
	
	
	@PostMapping(value="expense")
	public ResponseEntity<Boolean> add(@RequestBody Expense expense)//,@RequestParam("file") MultipartFile file
	{
		HttpStatus httpStatus;
		if(expenseService.addExpenses(expense)) {
			httpStatus = HttpStatus.OK;
		}
		else
		{
			httpStatus = HttpStatus.CONFLICT;
		}
		
		return new ResponseEntity<Boolean>(true,httpStatus);
	}
	
	@GetMapping(value="expense")
	public ResponseEntity<List<Expense>> get()
	{
		List<Expense> expenses = expenseService.getExpenses();
		HttpStatus httpStatus;
		
		if(expenses.size()!=0) {
			httpStatus = HttpStatus.OK;
		}
		else
		{
			httpStatus = HttpStatus.NO_CONTENT;
		}
		return new ResponseEntity<List<Expense>>(expenses,httpStatus);
	}
	
	
	@GetMapping(value="expense/{status}")
	public ResponseEntity<List<Expense>> getByStatus(@PathVariable("status") String status ){
		
		
		List<Expense> expenses = expenseService.getExpensesByStatus(Integer.parseInt(status));
		HttpStatus httpStatus;
		
		if(expenses.size()!=0) {
			httpStatus = HttpStatus.OK;
		}
		else
		{
			httpStatus = HttpStatus.NO_CONTENT;
		}
		
		return new ResponseEntity<List<Expense>>(expenses,httpStatus);
	}
	
}
