package com.acheron.configuration;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.servlet.WebSecurityEnablerConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.acheron.model.User;
import com.acheron.service.UserService;


@Configuration
@EnableWebSecurity
public class SecutiryConfiguration extends WebSecurityConfigurerAdapter
{

	@Autowired
	private UserService userService;

	
	@Autowired
	public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
		
		List<User> users= userService.getUsers();
		
		for (User user : users) {
			auth.inMemoryAuthentication().withUser(user.getUserName()).password("{noop}"+user.getPassword()).roles("USER");
		}
		
	}
	/*
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.csrf().disable().

				authorizeRequests().antMatchers(HttpMethod.OPTIONS, "/**").permitAll().anyRequest().authenticated()
				.and().httpBasic();
	}
	
	*/
	
	
	
	
	
/*	@Autowired
	public void configAuthentication(AuthenticationManagerBuilder auth) throws Exception {    
	
		auth.userDetailsService(userDetailsService).passwordEncoder(passwordencoder());
	} 

	
	@Override
	protected void configure(HttpSecurity http) throws Exception 
	{
	   http.authorizeRequests().antMatchers("/expense").access("hasRole('ADMIN')").anyRequest().permitAll()
	  .and().formLogin().loginPage("/login")
	    .usernameParameter("username").passwordParameter("password")
	  .and()
	    .logout().logoutSuccessUrl("/login?logout") 
	   .and()
	   .exceptionHandling().accessDeniedPage("/403");
	  /*.and().csrf()
	    
	 }
	
	
	@Bean(name="passwordEncoder")
    public PasswordEncoder passwordencoder()
	{
	     return new BCryptPasswordEncoder();
	}
	*/
}
