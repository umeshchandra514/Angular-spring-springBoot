package com.acheron.service;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.acheron.model.FileDB;
import com.acheron.repository.FileRepository;

@Service
public class FileDBService {

	@Autowired
	FileRepository fileRepository;
	
	
	public FileDB storeFile(MultipartFile file) throws IOException {
        // Normalize file name
        String fileName = StringUtils.cleanPath(file.getOriginalFilename());

            // Check if the file's name contains invalid characters
            if(fileName.contains("..")) {
                System.out.println("error in path");
            }

            FileDB dbFile = new FileDB(fileName, file.getContentType(), file.getBytes());

            return fileRepository.save(dbFile);
        
    }
	
	
	
	public FileDB getFile(String fileId) {
	        return fileRepository.getById(fileId);
	              
	}
	
	
}
