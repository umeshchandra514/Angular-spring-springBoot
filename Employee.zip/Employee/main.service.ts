import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { InterviewView } from './interview-requests/InterviewView';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MainService {

  employeeId:number
  constructor(private _http:HttpClient) { }

  //EMployee will get to see the requests from HR for Interviewing
  requests():Observable<HttpResponse<InterviewView[]>>{
    this.employeeId= 33//parseInt(sessionStorage.getItem("employee"))
    
    let URL:string ="http://localhost:8080/schedule/"+this.employeeId
    return this._http.get<InterviewView[]>(URL,{observe:'response'})
  }

  available(interviewId:number,availability:number){
    let URL:string = "http://localhost:8080/schedule/"+interviewId+"/"+availability
    return this._http.put(URL,{observe:'response'})
  }



}
