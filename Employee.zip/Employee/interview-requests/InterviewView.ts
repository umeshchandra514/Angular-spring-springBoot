export class InterviewView{

    constructor(
        private employeeId:string,
        private applicantName:string,
        private applicantJobRole:string,
        private applicantExperience:number,
        public dateOfInterview:Date,
        public interviewId:number
    ){}
}