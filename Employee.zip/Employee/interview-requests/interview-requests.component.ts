import { Component, OnInit } from '@angular/core';
import { MainService } from '../main.service';
import { InterviewView } from './InterviewView';

@Component({
  selector: 'app-interview-requests',
  templateUrl: './interview-requests.component.html',
  styleUrls: ['./interview-requests.component.css']
})
export class InterviewRequestsComponent implements OnInit {

  requests:InterviewView[]
  showData:boolean
  constructor(private _main:MainService) { }

  ngOnInit() {
    this.getRequests()
  }

  getRequests(){
    this._main.requests().subscribe(data =>{
      console.log("request"+data.body)
      if(data.status == 204){
          this.showData = false
      }
      else if(data.status == 200){
        this.showData = true
        this.requests = data.body
      }
    })
  }

  availabilty(interviewId:number,available:number){
      this._main.available(interviewId,available).subscribe(
         data =>{ this.getRequests()
          console.log('dd')
      })
  }



}
