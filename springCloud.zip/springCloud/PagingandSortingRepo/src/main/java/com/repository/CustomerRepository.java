package com.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Repository;

import com.model.CustomerDetails;


@Repository
public interface CustomerRepository extends PagingAndSortingRepository<CustomerDetails, Integer>,org.springframework.data.repository.Repository<CustomerDetails, Integer>//CrudRepository<CustomerDetails, Integer> 
{	
	public List<CustomerDetails> findByMobile(@Param("Mobilee") String Mobile);
	
	@Async
	public List<CustomerDetails> findOneByMobileAndCity(String Mobile,String city);
	
	@Async
	public List<CustomerDetails> findMobileByCityOrCity(String city,String city1);
}
