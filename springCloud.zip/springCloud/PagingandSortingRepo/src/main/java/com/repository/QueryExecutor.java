package com.repository;

import org.springframework.data.repository.query.QueryByExampleExecutor;
import org.springframework.stereotype.Repository;

import com.model.CustomerDetails;

@Repository
public interface QueryExecutor extends QueryByExampleExecutor<CustomerDetails>{

}
