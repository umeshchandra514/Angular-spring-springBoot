package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Slice;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Service;

import com.model.CustomerDetails;
import com.repository.CustomerRepository;



@Service
public class CustomerServiceImpl implements CustomerService{

	
	@Autowired
	CustomerRepository customerRepository;
	
	
	@Override
	public CustomerDetails addCustomer(CustomerDetails customer) {
		//return customerRepository.save(customer)!=null;
		return customerRepository.save(customer);
		
		
	}

	@Override
	public boolean updateCustomer(CustomerDetails customer) {
		return customerRepository.save(customer)!=null;
		
	}

	@Override
	public void deleteCustomer(int customerId) {
		 customerRepository.deleteById(customerId);
	}

	/*
	 * @Override public CustomerDetails findCustomer(int customerId) { return
	 * customerRepository.findById(customerId);
	 * 
	 * }
	 */


    @Override
	public boolean isCustomerExists(int customerId) {
		return false;//customerRepository.(customerId);
		
	}

	@Override
	public Iterable<CustomerDetails> getCustomers() {
		return customerRepository.findAll();
	
	}
	
	@Override
	public List<CustomerDetails> findCustomers(String Mobile) {
		return customerRepository.findOneByMobileAndCity(Mobile,"hyderabad");
		 
	
	}

	@Override
	public CustomerDetails findCustomer(int customerId) {
		// TODO Auto-generated method stub
		return null;
	}

	@SuppressWarnings("deprecation")
	@Override
	public Slice<CustomerDetails> getPagingg() {	
		return customerRepository.findAll(new PageRequest(1,1));
	}

	@SuppressWarnings({ "unchecked", "deprecation" })
	@Override
	public List<CustomerDetails> getPaginggSlice() {
		// TODO Auto-generated method stub
		return (List<CustomerDetails>) customerRepository.findAll(new PageRequest(1,1));
	}
	

	
}
