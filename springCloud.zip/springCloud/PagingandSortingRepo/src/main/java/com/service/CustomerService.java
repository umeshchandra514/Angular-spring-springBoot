package com.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Slice;

import com.model.CustomerDetails;

public interface CustomerService {

	public CustomerDetails addCustomer(CustomerDetails customer);
	public boolean updateCustomer(CustomerDetails customer);
	public void deleteCustomer(int customerId);
	public CustomerDetails findCustomer(int customerId);
	public boolean isCustomerExists(int customerId);
	public Iterable<CustomerDetails> getCustomers();
	public List<CustomerDetails> findCustomers(String Mobile);
	public Slice<CustomerDetails> getPagingg();
	public List<CustomerDetails> getPaginggSlice();
	
}
