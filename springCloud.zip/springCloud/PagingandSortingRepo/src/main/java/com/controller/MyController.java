package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Slice;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.model.CustomerDetails;
import com.service.CustomerService;



@RestController
public class MyController {
	
	@Autowired
	CustomerService customerService;

	@RequestMapping("umesh")
	public String getUmesh()
	{
		return "hello";
	}
	
	
	@GetMapping("pagingGet")
	public ResponseEntity<Slice<CustomerDetails>> getPaging()
	{
		Slice<CustomerDetails> details = customerService.getPagingg();
		return new ResponseEntity<Slice<CustomerDetails>>(details,HttpStatus.OK);
	}
	
	@GetMapping("pagingGetSlice")
	public ResponseEntity<List<CustomerDetails>> getPagingSlice()
	{
		List<CustomerDetails> details = customerService.getPaginggSlice();
		return new ResponseEntity<List<CustomerDetails>>(details,HttpStatus.OK);
	}
	
	@RequestMapping(value="/save", method = RequestMethod.POST)
	public CustomerDetails doSave(@RequestBody CustomerDetails customer)
	{
		CustomerDetails details = customerService.addCustomer(customer);
		System.out.println(details);
		return details;
		//return customer;//customerService.addCustomer(customer);
	
	}
	
	@RequestMapping(value="/gett", method = RequestMethod.GET)
	public ResponseEntity<Iterable<CustomerDetails>> doGet()
	{
		return new ResponseEntity<Iterable<CustomerDetails>>(customerService.getCustomers(),HttpStatus.OK);
	}
	
	
	@RequestMapping(value="/getMobile", method = RequestMethod.GET)
	public ResponseEntity<Iterable<CustomerDetails>> doGet1()
	{
		return new ResponseEntity<Iterable<CustomerDetails>>(customerService.findCustomers("8125253848"),HttpStatus.OK);
	}
	
}
