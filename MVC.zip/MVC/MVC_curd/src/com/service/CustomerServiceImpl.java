package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.dao.CustomerDAO;
import com.model.CustomerDetails;

public class CustomerServiceImpl implements CustomerService{

	
	CustomerDAO customerDao;
	
	
	public void setCustomerDao(CustomerDAO customerDao) {
		this.customerDao = customerDao;
	}
	
	public CustomerDAO getCustomerDao() {
		return customerDao;
	}
	
	
	@Override
	public boolean addCustomer(CustomerDetails customer) {
		return customerDao.addCustomer(customer);
		
	}

	@Override
	public boolean updateCustomer(CustomerDetails customer) {
		return customerDao.updateCustomer(customer);
		
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		return customerDao.deleteCustomer(customerId);
		
	}

	@Override
	public CustomerDetails findCustomer(int customerId) {
		return customerDao.findCustomer(customerId);
		
	}

	@Override
	public boolean isCustomerExists(int customerId) {
		return customerDao.isCustomerExists(customerId);
		
	}

	@Override
	public List<CustomerDetails> getCustomers() {
		return customerDao.getCustomers();
		
	}

}
