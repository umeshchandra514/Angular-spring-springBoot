package com.dao;

import java.util.List;

import com.model.CustomerDetails;

public interface CustomerDAO {

	public boolean addCustomer(CustomerDetails customer);
	public boolean updateCustomer(CustomerDetails customer);
	public boolean deleteCustomer(int customerId);
	public CustomerDetails findCustomer(int customerId);
	public boolean isCustomerExists(int customerId);
	public List<CustomerDetails> getCustomers();
}
