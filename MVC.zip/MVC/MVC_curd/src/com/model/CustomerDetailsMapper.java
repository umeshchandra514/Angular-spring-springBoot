package com.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class CustomerDetailsMapper implements RowMapper<CustomerDetails>{

	@Override
	public CustomerDetails mapRow(ResultSet rs, int arg1) throws SQLException {
		
		CustomerDetails customer = new CustomerDetails();
		
		customer.setCustomerId(rs.getInt("customerId"));
		customer.setCustomerFullName(rs.getString("customerFullName"));
		customer.setEmail(rs.getString("email"));
		customer.setMobile(rs.getString("mobile"));
		customer.setCity(rs.getString("city"));
		customer.setGender(rs.getString("gender"));
		customer.setCustomerType(rs.getString("customertype"));
		customer.setBillDate(rs.getDate("billDate"));
		customer.setIsActive(rs.getBoolean("isActive"));
		
		
		return customer;
	}
	
	

}
