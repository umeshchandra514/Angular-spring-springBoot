package com.acheron.model;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotNull;


@Entity
public class Expense {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer expenseId;
	
	@OneToMany(cascade = CascadeType.ALL)//,orphanRemoval = true  //mappedBy = "expense",
	private List<BillDetails> billdetails;
	
	@NotNull
	private Integer employeeId;
	@NotNull
	private Integer status;
	
	
	public Expense() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	public Expense(Integer expenseId, List<BillDetails> billdetails, Integer employeeId, Integer status) {
		super();
		this.expenseId = expenseId;
		this.billdetails = billdetails;
		this.employeeId = employeeId;
		this.status = status;
		
		System.out.println(billdetails);
	}






	public Integer getExpenseId() {
		return expenseId;
	}
	public void setExpenseId(Integer expenseId) {
		this.expenseId = expenseId;
	}
	public List<BillDetails> getBilldetails() {
		System.out.println("get" + billdetails);
		return billdetails;
	}
	public void setBilldetails(List<BillDetails> billdetails) {
		
		this.billdetails = billdetails;
		System.out.println("set" + billdetails + this.billdetails);
	}
	public Integer getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "Expense [expenseId=" + expenseId + ", billdetails=" + billdetails + ", employeeId=" + employeeId
				+ ", status=" + status + "]";
	}
	
		
	
}
