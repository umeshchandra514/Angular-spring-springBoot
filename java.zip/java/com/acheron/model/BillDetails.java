package com.acheron.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
//import javax.persistence.JoinColumn;
//import javax.persistence.ManyToOne;
//import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

//import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
public class BillDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer billDetailsId;
	
	@DateTimeFormat(pattern = "YYYY-MM-DD")
	private Date date;
	private String Category;
	private String billPrice;
	
	
	
	
	//	//@JoinColumn(name = "expenseId")
	//@ManyToOne()
	//private Expense expense;

	public BillDetails() {
		// TODO Auto-generated constructor stub
	}


	public BillDetails(Integer billDetailsId, Date date, String category, String billPrice) {
		super();
		this.billDetailsId = billDetailsId;
		this.date = date;
		Category = category;
		this.billPrice = billPrice;
	}
	
	
	
	public Integer getBillDetailsId() {
		return billDetailsId;
	}


	public void setBillDetailsId(Integer billDetailsId) {
		this.billDetailsId = billDetailsId;
	}


	public Date getDate() {
		return date;
	}


	public void setDate(Date date) {
		this.date = date;
	}


	public String getCategory() {
		return Category;
	}


	public void setCategory(String category) {
		Category = category;
	}


	public String getBillPrice() {
		return billPrice;
	}


	public void setBillPrice(String billPrice) {
		this.billPrice = billPrice;
	}


	@Override
	public String toString() {
		return "BillDetails [billDetailsId=" + billDetailsId + ", date=" + date + ", Category=" + Category
				+ ", billPrice=" + billPrice + "]";
	}




	
	

		
	

	
}
