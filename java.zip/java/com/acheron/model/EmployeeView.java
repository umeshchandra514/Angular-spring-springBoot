package com.acheron.model;

import org.springframework.beans.factory.annotation.Value;

public interface EmployeeView{
	
	public String getEmployeeName();
}
