package com.acheron.model.repository;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;

import org.hibernate.validator.constraints.NotBlank;

@Entity
@Table(name = "recruitment_applicant_form")
public class ApplicantForm {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer applicantId;
	
	@NotBlank
	private String applicantName;	
	@Email
	private String applicantEmail;
	
	@NotBlank
	private String applicantContactNumber;
	private String applicantAlternateNumber;
	
	@NotBlank
	private String applicantDegree;
	private Integer applicantExperience;
	
	@NotBlank
	private String applicantJobRole;
	
	private Integer isShortlisted=0;
	
	
	public ApplicantForm() {
		// TODO Auto-generated constructor stub
	}

	
	

	public ApplicantForm(Integer applicantId, @NotBlank String applicantName, @Email String applicantEmail,
			@NotBlank String applicantContactNumber, String applicantAlternateNumber, @NotBlank String applicantDegree,
			Integer applicantExperience, @NotBlank String applicantJobRole, Integer isShortlisted) {
		super();
		this.applicantId = applicantId;
		this.applicantName = applicantName;
		this.applicantEmail = applicantEmail;
		this.applicantContactNumber = applicantContactNumber;
		this.applicantAlternateNumber = applicantAlternateNumber;
		this.applicantDegree = applicantDegree;
		this.applicantExperience = applicantExperience;
		this.applicantJobRole = applicantJobRole;
		this.isShortlisted = isShortlisted;
	}




	public Integer getApplicantId() {
		return applicantId;
	}




	public void setApplicantId(Integer applicantId) {
		this.applicantId = applicantId;
	}




	public String getApplicantName() {
		return applicantName;
	}




	public void setApplicantName(String applicantName) {
		this.applicantName = applicantName;
	}




	public String getApplicantEmail() {
		return applicantEmail;
	}




	public void setApplicantEmail(String applicantEmail) {
		this.applicantEmail = applicantEmail;
	}




	public String getApplicantContactNumber() {
		return applicantContactNumber;
	}




	public void setApplicantContactNumber(String applicantContactNumber) {
		this.applicantContactNumber = applicantContactNumber;
	}




	public String getApplicantAlternateNumber() {
		return applicantAlternateNumber;
	}




	public void setApplicantAlternateNumber(String applicantAlternateNumber) {
		this.applicantAlternateNumber = applicantAlternateNumber;
	}




	public String getApplicantDegree() {
		return applicantDegree;
	}




	public void setApplicantDegree(String applicantDegree) {
		this.applicantDegree = applicantDegree;
	}




	public Integer getApplicantExperience() {
		return applicantExperience;
	}




	public void setApplicantExperience(Integer applicantExperience) {
		this.applicantExperience = applicantExperience;
	}




	public String getApplicantJobRole() {
		return applicantJobRole;
	}




	public void setApplicantJobRole(String applicantJobRole) {
		this.applicantJobRole = applicantJobRole;
	}

	
	public Integer getIsShortlisted() {
		return isShortlisted;
	}



	public void setIsShortlisted(Integer isShortlisted) {
		this.isShortlisted = isShortlisted;
	}




	@Override
	public String toString() {
		return "RecruitmentApplicantForm [applicantId=" + applicantId + ", applicantName=" + applicantName
				+ ", applicantEmail=" + applicantEmail + ", applicantContactNumber=" + applicantContactNumber
				+ ", applicantAlternateNumber=" + applicantAlternateNumber + ", applicantDegree=" + applicantDegree
				+ ", applicantExperience=" + applicantExperience + ", applicantJobRole=" + applicantJobRole
				+ ", isShortlisted=" + isShortlisted + "]";
	}





	
}
