package com.acheron.model.repository;

import java.util.Date;

import org.springframework.beans.factory.annotation.Value;

public interface InterviewView{
	
	//----Open projections 
	@Value("#{target.employee_id}")//property name
	public String getEmployeeId(); 
	
	@Value("#{target.applicant_name}")
	public String getApplicantName();
	
	@Value("#{target.applicant_job_role}")
	public String getApplicantJobRole();
	
	@Value("#{target.applicant_experience}")
	public Integer getApplicantExperience();
	
	@Value("#{target.date_of_interview}")
	public Date getDateOfInterview();
	
	
	
	@Value("#{target.id}")
	public Integer getInterviewId();
}
