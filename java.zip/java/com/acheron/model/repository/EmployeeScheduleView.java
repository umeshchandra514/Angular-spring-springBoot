package com.acheron.model.repository;

import org.springframework.beans.factory.annotation.Value;

public interface EmployeeScheduleView {
	
	
	@Value("#{target.employee_name}")
	public String getEmployeeName();
	
	@Value("#{target.applicant_name}")
	public String getApplicantName();

	@Value("#{target.applicant_job_role}")
	public String getApplicantJobRole();
	
	@Value("#{target.employee_id}")
	public String getInterviewEmpId();
	
	@Value("#{target.availability}")
	public String getAvailability();
	
}
