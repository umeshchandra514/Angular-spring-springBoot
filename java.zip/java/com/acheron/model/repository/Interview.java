package com.acheron.model.repository;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

import com.acheron.model.Employee;

@Entity
@Table(name = "recruitment_interview")
public class Interview {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	
	@ManyToOne
	@JoinColumn(name = "applicantId")
	private ApplicantForm recruitmentForm;

	@OneToOne
	@JoinColumn(name = "employeeId")
	private Employee employee;
	
	@DateTimeFormat(pattern = "yyyy-mm-dd")
	private Date dateOfInterview;
	private Integer availability=0; // 0=fresh, 1=available for interview , 2= not available to be in interview panel 
	
	
	public Interview() {
		// TODO Auto-generated constructor stub
	}


	public Interview(Integer id, ApplicantForm recruitmentForm, Employee employee, Date dateOfInterview,
			Integer availability) {
		super();
		this.id = id;
		this.recruitmentForm = recruitmentForm;
		this.employee = employee;
		this.dateOfInterview = dateOfInterview;
		this.availability = availability;
	}


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public ApplicantForm getRecruitmentForm() {
		return recruitmentForm;
	}


	public void setRecruitmentForm(ApplicantForm recruitmentForm) {
		this.recruitmentForm = recruitmentForm;
	}


	public Employee getEmployee() {
		return employee;
	}


	public void setEmployee(Employee employee) {
		this.employee = employee;
	}


	public Date getDateOfInterview() {
		return dateOfInterview;
	}


	public void setDateOfInterview(Date dateOfInterview) {
		this.dateOfInterview = dateOfInterview;
	}


	public Integer getAvailability() {
		return availability;
	}


	public void setAvailability(Integer availability) {
		this.availability = availability;
	}


	@Override
	public String toString() {
		return "Interview [id=" + id + ", recruitmentForm=" + recruitmentForm + ", employee=" + employee
				+ ", dateOfInterview=" + dateOfInterview + ", availability=" + availability + "]";
	}




	
}
