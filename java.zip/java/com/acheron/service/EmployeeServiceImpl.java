package com.acheron.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.acheron.model.Employee;
import com.acheron.model.EmployeeView;
import com.acheron.repository.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeRepository employeeRepository;
	@Override
	public List<Employee> getEmployees() {
		return  (List<Employee>) employeeRepository.findAll();
	}

	@Override
	public Employee addEmployee(Employee employee) {
		
		return employeeRepository.save(employee);
	}
	@Override
	public Optional<Employee> getEmployee(int employeeId) {
		// TODO Auto-generated method stub
		return employeeRepository.findById(employeeId);
	}
	
	@Override
	public EmployeeView getEmployeeName(Integer employeeId) {
		if(employeeRepository.existsById(employeeId)) {
			return employeeRepository.findEmployeeNameByEmployeeId(employeeId);
		}
		else
		{
			return null;
		}
	}

}
