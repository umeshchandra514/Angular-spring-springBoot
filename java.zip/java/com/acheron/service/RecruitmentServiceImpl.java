package com.acheron.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.acheron.model.repository.EmployeeScheduleView;
import com.acheron.model.Employee;
import com.acheron.model.repository.ApplicantForm;
import com.acheron.model.repository.Interview;
import com.acheron.model.repository.InterviewView;
import com.acheron.repository.EmployeeRepository;
import com.acheron.repository.RecruitmentFormRepository;
import com.acheron.repository.RecruitmentInterviewRepository;




@Service
public class RecruitmentServiceImpl implements RecruitmentService {

	
	@Autowired
	RecruitmentFormRepository recruitmentFormRepository;
	
	@Autowired
	RecruitmentInterviewRepository recruitmentInterviewRepository;
	
	@Autowired
	EmployeeRepository employeeRepository;
	
	
	@Override
	public ApplicantForm addApplicant(ApplicantForm recruitmentApplicantForm) {
		System.out.println(recruitmentApplicantForm);
		return recruitmentFormRepository.save(recruitmentApplicantForm);
		
	}

	@Override
	public List<ApplicantForm> getApplicants() {
		return (List<ApplicantForm>) recruitmentFormRepository.findByIsShortlisted(0);
	}
	
	
	
	@Override
	public Optional<ApplicantForm> getApplicantById(Integer applicantId) {
		return recruitmentFormRepository.findById(applicantId);
	}
	
	
	@Override
	public ApplicantForm shortlisted(ApplicantForm recruitmentApplicantForm) {
		return recruitmentFormRepository.save(recruitmentApplicantForm);
	}


	@Override
	public List<ApplicantForm> getshortlist(Integer isShortlisted) {
		return recruitmentFormRepository.findByIsShortlisted(isShortlisted);
	}
	
	//-------Schedule----------
	@Override
	public Interview scheduleInterview(Interview recruitmentInterview,Integer applicantId,Integer employeeId)
	{
		System.out.println(recruitmentFormRepository.findById(applicantId).get());
		
		Optional<ApplicantForm> form = recruitmentFormRepository.findById(applicantId);
		if(form.isPresent()) 
		{
			recruitmentInterview.setRecruitmentForm(form.get());
			Optional<Employee> employee=employeeRepository.findById(employeeId);
			if(employee.isPresent())
			{
				recruitmentInterview.setEmployee(employee.get());
				return recruitmentInterviewRepository.save(recruitmentInterview);
			}
			else{
				return null;
			}
		}	
		else{
			return null;
		}
	
	}

	
	@Override
	public List<InterviewView> fetchByEmp(Employee Employee) {
		return recruitmentInterviewRepository.fetchDetailsByEmployee(Employee.getEmployeeId());
	}

	@Override
	public Optional<Interview> find(Integer id) {
		
		return recruitmentInterviewRepository.findById(id);
	}
	
	
	@Override
	public List<EmployeeScheduleView> fetch(Integer availability){
		return recruitmentInterviewRepository.findEmployeeAvailability(availability);
	}
	
	//------------------
	
	
	
	
	
}
