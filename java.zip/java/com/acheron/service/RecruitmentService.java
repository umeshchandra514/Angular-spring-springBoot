package com.acheron.service;

import java.util.List;
import java.util.Optional;

import com.acheron.model.repository.EmployeeScheduleView;
import com.acheron.model.Employee;
import com.acheron.model.repository.ApplicantForm;
import com.acheron.model.repository.Interview;
import com.acheron.model.repository.InterviewView;


public interface RecruitmentService {

	ApplicantForm addApplicant(ApplicantForm recruitmentApplicantForm);

	List<ApplicantForm> getApplicants();
	
	Interview scheduleInterview(Interview recruitmentInterview, Integer applicantId, Integer employeeId);
	
	List<InterviewView> fetchByEmp(Employee employee);

	Optional<Interview> find(Integer availability);

	List<EmployeeScheduleView> fetch(Integer availability);

	ApplicantForm shortlisted(ApplicantForm recruitmentShortList);

	Optional<ApplicantForm> getApplicantById(Integer applicantId);

	List<ApplicantForm> getshortlist(Integer isShortlisted);

	

	

}
