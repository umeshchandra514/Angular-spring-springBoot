package com.acheron.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.acheron.model.Expense;

public interface ExpenseRepository extends CrudRepository<Expense, Integer> {
	
	List<Expense> findByStatus(Integer status);

}
