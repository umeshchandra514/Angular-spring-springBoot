package com.acheron.property.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class Property {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	public int propertyId;
	
	@NotBlank(message="enter Location ")
	public String propertyLocation="dd";
	
	@Column(length=100)
	public String propertyAddress;
	@Column(length=100)
	public String propertyDescription;
	public String propertySaleRent;
	public String propertyType;
	public int propertyPrice;
	public String propertyContact;
	
	public boolean wishlist ;
	public Property() {
		// TODO Auto-generated constructor stub
	}

	

	public Property(int propertyId, String propertyLocation, String propertyAddress, String propertyDescription,
			String propertySaleRent, String propertyType, int propertyPrice, String propertyContact, boolean wishlist) {
		super();
		this.propertyId = propertyId;
		this.propertyLocation = propertyLocation;
		this.propertyAddress = propertyAddress;
		this.propertyDescription = propertyDescription;
		this.propertySaleRent = propertySaleRent;
		this.propertyType = propertyType;
		this.propertyPrice = propertyPrice;
		this.propertyContact = propertyContact;
		this.wishlist = wishlist;
	}



	public int getPropertyId() {
		return propertyId;
	}


	public void setPropertyId(int propertyId) {
		this.propertyId = propertyId;
	}


	public String getPropertyLocation() {
		return propertyLocation;
	}


	public void setPropertyLocation(String propertyLocation) {
		this.propertyLocation = propertyLocation;
	}


	public String getPropertyAddress() {
		return propertyAddress;
	}


	public void setPropertyAddress(String propertyAddress) {
		this.propertyAddress = propertyAddress;
	}


	public String getPropertyDescription() {
		return propertyDescription;
	}


	public void setPropertyDescription(String propertyDescription) {
		this.propertyDescription = propertyDescription;
	}


	public String getPropertySaleRent() {
		return propertySaleRent;
	}


	public void setPropertySaleRent(String propertySaleRent) {
		this.propertySaleRent = propertySaleRent;
	}


	public String getPropertyType() {
		return propertyType;
	}


	public void setPropertyType(String propertyType) {
		this.propertyType = propertyType;
	}


	public int getPropertyPrice() {
		return propertyPrice;
	}


	public void setPropertyPrice(int propertyPrice) {
		this.propertyPrice = propertyPrice;
	}


	public String getPropertyContact() {
		return propertyContact;
	}


	public void setPropertyContact(String propertyContact) {
		this.propertyContact = propertyContact;
	}

	
	
	public boolean isWishlist() {
		return wishlist;
	}



	public void setWishlist(boolean wishlist) {
		this.wishlist = wishlist;
	}



	@Override
	public String toString() {
		return "Property [propertyId=" + propertyId + ", propertyLocation=" + propertyLocation + ", propertyAddress="
				+ propertyAddress + ", propertyDescription=" + propertyDescription + ", propertySaleRent="
				+ propertySaleRent + ", propertyType=" + propertyType + ", propertyPrice=" + propertyPrice
				+ ", propertyContact=" + propertyContact + ", wishlist=" + wishlist + "]";
	}




	

	
	
	
}
