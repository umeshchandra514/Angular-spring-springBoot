package com.acheron.property.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.acheron.property.model.Login;

import com.acheron.property.repository.LoginRepository;

@Service
public class LoginServiceImpl implements LoginService {


	
	@Autowired
	LoginRepository loginRepository;
	
	@Override
	public Login userValidation(Login login)
	{ 
		return loginRepository.findByPasswordAndUsernameIgnoreCase( login.getPassword(),login.getUsername());
	}
	
	
	
}
