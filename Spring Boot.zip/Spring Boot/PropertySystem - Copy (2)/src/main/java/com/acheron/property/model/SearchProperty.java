package com.acheron.property.model;

public class SearchProperty {

	private String searchPropertyLocation;
	private String searchSaleRent;
	private int searchMinimumPrice;
	private int searchMaximumPrice;
	private String searchHouseType;
	
	
	public SearchProperty() {
		// TODO Auto-generated constructor stub
	}


	public SearchProperty(String searchPropertyLocation, String searchSaleRent, int searchMinimumPrice,
			int searchMaximumPrice, String searchHouseType) {
		super();
		this.searchPropertyLocation = searchPropertyLocation;
		this.searchSaleRent = searchSaleRent;
		this.searchMinimumPrice = searchMinimumPrice;
		this.searchMaximumPrice = searchMaximumPrice;
		this.searchHouseType = searchHouseType;
	}


	public String getSearchPropertyLocation() {
		return searchPropertyLocation;
	}


	public void setSearchPropertyLocation(String searchPropertyLocation) {
		this.searchPropertyLocation = searchPropertyLocation;
	}


	public String getSearchSaleRent() {
		return searchSaleRent;
	}


	public void setSearchSaleRent(String searchSaleRent) {
		this.searchSaleRent = searchSaleRent;
	}


	public int getSearchMinimumPrice() {
		return searchMinimumPrice;
	}


	public void setSearchMinimumPrice(int searchMinimumPrice) {
		this.searchMinimumPrice = searchMinimumPrice;
	}


	public int getSearchMaximumPrice() {
		return searchMaximumPrice;
	}


	public void setSearchMaximumPrice(int searchMaximumPrice) {
		this.searchMaximumPrice = searchMaximumPrice;
	}


	public String getSearchHouseType() {
		return searchHouseType;
	}


	public void setSearchHouseType(String searchHouseType) {
		this.searchHouseType = searchHouseType;
	}


	@Override
	public String toString() {
		return "SearchProperty [searchPropertyLocation=" + searchPropertyLocation + ", searchSaleRent=" + searchSaleRent
				+ ", searchMinimumPrice=" + searchMinimumPrice + ", searchMaximumPrice=" + searchMaximumPrice
				+ ", searchHouseType=" + searchHouseType + "]";
	}
	
	
}
