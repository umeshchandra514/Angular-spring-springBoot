package com.acheron.property.service;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RestController;

import com.acheron.property.model.Login;



public interface LoginService {

	Login userValidation(Login login);

}
