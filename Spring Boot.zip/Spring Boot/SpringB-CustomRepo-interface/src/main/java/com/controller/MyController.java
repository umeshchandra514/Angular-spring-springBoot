package com.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.model.CustomerDetails;
import com.service.CustomerService;




/* @CrossOrigin(origins = {"http://localhost:4200"}) */
@RestController
public class MyController {
	
	@Autowired
	CustomerService customerService;

	@RequestMapping("/umesh")
	public String getUmesh()
	{
		return "hello";
	}
	
	@RequestMapping(value="/product", method = RequestMethod.POST)
	public CustomerDetails doSave(@RequestBody CustomerDetails customer)
	{
		CustomerDetails details = customerService.addCustomer(customer);
		System.out.println(details);
		return details;
		//return customer;//customerService.addCustomer(customer);
	
	}
	
	@RequestMapping(value="/product", method = RequestMethod.GET)
	public ResponseEntity<List<CustomerDetails>> doGet()
	{
		System.out.println(customerService.getCustomers());
		return new ResponseEntity<List<CustomerDetails>>(customerService.getCustomers(),HttpStatus.OK);
				
	}
	
	@RequestMapping(value="/product/{customerId}",method = RequestMethod.DELETE)
	public ResponseEntity<Integer> doDelete(@PathVariable("customerId")Integer customerId) {
		HttpStatus status = customerService.deleteCustomer(customerId);
		return new ResponseEntity<Integer>(status);
	}
	
	
	
	@RequestMapping(value="products", method = RequestMethod.GET)
	public ResponseEntity<Optional<CustomerDetails>> doGetById()//Integer.parseInt(
	{ 
	 // String productId ="12";	 
      Optional<CustomerDetails> customer = customerService.findCustomer(12);//Integer.parseInt(productId)
		  
	  if(customer.isPresent()) { 
		  return new ResponseEntity<Optional<CustomerDetails>>(customer,HttpStatus.OK);
	  }
	  else 
	  {
		  return new ResponseEntity<Optional<CustomerDetails>>(customer,HttpStatus.NO_CONTENT);
	  }
	  
	}
	
	
	
	
	
	@RequestMapping(value="/product",method = RequestMethod.PUT)
	public ResponseEntity<Integer> doUpdate(@RequestBody CustomerDetails customer) {
		HttpStatus status = customerService.updateCustomer(customer);
		
		return new ResponseEntity<Integer>(status);
	}
	
	
	/*
	 * @CrossOrigin(origins = {"http://localhost:4200"})
	 * 
	 * @RequestMapping(value="product/{productId}" ,method = RequestMethod.GET) public
	 * ResponseEntity<Optional<CustomerDetails>>
	 * doGetById(@PathVariable("productId")Integer productId) { //return
	 * customerService.findCustomer(productId); Optional<CustomerDetails> customer =
	 * customerService.findCustomer(productId);
	 * 
	 * if(customer.isPresent()) { return new
	 * ResponseEntity<Optional<CustomerDetails>>(customer,HttpStatus.OK); } else {
	 * return new
	 * ResponseEntity<Optional<CustomerDetails>>(customer,HttpStatus.NO_CONTENT); }
	 * 
	 * }
	 */
	
	//@RequestParam("id")
	  
	 	
}
