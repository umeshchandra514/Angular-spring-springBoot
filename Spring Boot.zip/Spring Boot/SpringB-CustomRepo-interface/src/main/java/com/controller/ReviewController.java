package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.model.Reviews;
import com.service.ReviewService;

@RestController
@RequestMapping(value = "/product")
public class ReviewController {

	@Autowired
	ReviewService reviewService;
	
	 @RequestMapping(value="/{productId}/review",method = RequestMethod.GET)
	 public List<Reviews> getReview(@PathVariable("productId") Integer productId)
	 {
		 return reviewService.getReviewByPId(productId);
	   
	 }
	 
	 @RequestMapping(value="/review",method = RequestMethod.GET)
	 public List<Reviews> getReview()
	 {
		 return reviewService.getReviews();
	 }
	 

	@RequestMapping(value = "/{productId}/review", method = RequestMethod.POST)
	public Reviews addReview(@RequestBody Reviews review, @PathVariable("productId") Integer productId) {
		review.setProductID(productId);
		reviewService.addReview(review);
		return review;
	}
	
	
	@RequestMapping(value = "/{productId}/review/{reviewId}", method = RequestMethod.GET)
	public Reviews getReview(@PathVariable("productId") Integer productId, @PathVariable("reviewId") Integer reviewId) {
		
		return reviewService.getReviewByPIdRId(productId,reviewId);
		
	}
	
	
	@RequestMapping(value = "/{productId}/fetch/{count}/reviews", method = RequestMethod.GET)
	public List<Reviews> getReviewes(@PathVariable("productId") Integer productId, @PathVariable("count") Integer count) {
		
		return reviewService.getReviewsOfPid(productId,count);
		
	}
	
}
