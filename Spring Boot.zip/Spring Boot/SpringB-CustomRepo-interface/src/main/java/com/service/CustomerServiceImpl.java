package com.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.model.CustomerDetails;
import com.repository.CustomerRepository;


@Service
public class CustomerServiceImpl implements CustomerService{

	@Autowired
	CustomerRepository customerRepository;
	
	
	
	
	
	@Override
	public CustomerDetails addCustomer(CustomerDetails customer) {
		//return customerRepository.save(customer)!=null;
		return customerRepository.save(customer);
		
		
	}

	@Override
	public HttpStatus updateCustomer(CustomerDetails customer) {
		if(isCustomerExists(customer.getCustomerId()))
		{
			
			customerRepository.save(customer);
			return HttpStatus.OK;
		}
		else
		{
			
			return HttpStatus.NO_CONTENT;
		}
	}

	@Override
	public HttpStatus deleteCustomer(int customerId) {
		if(isCustomerExists(customerId))
		{
		 customerRepository.deleteById(customerId);
		 return HttpStatus.OK;
		}
		else
		{
			return HttpStatus.NO_CONTENT;
		}
	}

	/*
	 * @Override public CustomerDetails findCustomer(int customerId) { return
	 * customerRepository.findById(customerId);
	 * 
	 * }
	 */


   @Override
	public boolean isCustomerExists(int customerId) {
		return customerRepository.existsById(customerId);
		
	}

	@Override
	public List<CustomerDetails> getCustomers() {
		//System.out.println(customerRepository.findAll());
		return (List<CustomerDetails>) customerRepository.findAll();
	
	}
	
	@Override
	public List<CustomerDetails> findCustomers(String Mobile) {
		return customerRepository.findByMobile(Mobile);
		 
	
	}

	@Override
	public Optional<CustomerDetails> findCustomer(int customerId) {
		/*
		 * // TODO Auto-generated method stub if(customerRepository.findById(customerId)
		 * == null) { return null; } else { return
		 * customerRepository.findById(customerId); }
		 */
		return customerRepository.findById(customerId);
		
	}
	

}
