package com.service;

import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpStatus;

import com.model.CustomerDetails;

public interface CustomerService {

	public CustomerDetails addCustomer(CustomerDetails customer);
	public HttpStatus updateCustomer(CustomerDetails customer);
	public HttpStatus deleteCustomer(int customerId);
	public Optional<CustomerDetails> findCustomer(int customerId);
	public boolean isCustomerExists(int customerId);
	public List<CustomerDetails> getCustomers();
	public List<CustomerDetails> findCustomers(String Mobile);
	
}
