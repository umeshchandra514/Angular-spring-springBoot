package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.Reviews;
import com.repository.ReviewRepository;

@Service
public class ReviewServiceImpl implements ReviewService{

	@Autowired
	ReviewRepository reviewRepository;
	
	@Autowired
	

	@Override
	public void addReview(Reviews review) {
		reviewRepository.save(review);
	}


	@Override
	public List<Reviews> getReviewByPId(Integer productId) {
		
		return reviewRepository.findByProductID(productId);
		
	}


	@Override
	public List<Reviews> getReviews() {
		return (List<Reviews>) reviewRepository.findAll();
		
	}


	@Override
	public Reviews getReviewByPIdRId(Integer productId, Integer reviewId) {
		return reviewRepository.fetchByPIdRId(productId, reviewId);
		
	}


	@Override
	public List<Reviews> getReviewsOfPid(Integer productId, Integer count) {
		
		return reviewRepository.fetchReviewsByCount(productId, count);
	}

	
	
}
