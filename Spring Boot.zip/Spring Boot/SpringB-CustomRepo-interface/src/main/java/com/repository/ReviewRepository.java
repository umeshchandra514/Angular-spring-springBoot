package com.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.model.Reviews;

@Repository
public interface ReviewRepository extends CrudRepository<Reviews, Integer>{

	List<Reviews> findByProductID(Integer productID);
	
	@Query(value="select * from reviews where productid = ?1 AND review_id = ?2", nativeQuery = true)
	Reviews fetchByPIdRId(Integer productId,Integer reviewID);
	
	
	@Query(value="select * from reviews where productid = ?1 LIMIT ?2",nativeQuery = true)
	List<Reviews> fetchReviewsByCount(Integer productId , Integer count);
	
}
