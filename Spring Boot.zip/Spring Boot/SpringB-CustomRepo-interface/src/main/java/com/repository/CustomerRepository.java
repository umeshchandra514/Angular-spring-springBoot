package com.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.model.CustomerDetails;


@Repository
public interface CustomerRepository extends CrudRepository<CustomerDetails, Integer> {
	
	public List<CustomerDetails> findByMobile(String Mobile);

}
