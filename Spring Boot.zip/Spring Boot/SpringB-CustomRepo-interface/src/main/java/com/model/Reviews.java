package com.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Reviews {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	Integer reviewId;
	String review;
	Integer productID;
	
	public Reviews() {
		// TODO Auto-generated constructor stub
	}

	public Reviews(Integer reviewId, String review, Integer productID) {
		super();
		this.reviewId = reviewId;
		this.review = review;
		this.productID = productID;
	}

	public Integer getReviewId() {
		return reviewId;
	}

	public void setReviewId(Integer reviewId) {
		this.reviewId = reviewId;
	}

	public String getReview() {
		return review;
	}

	public void setReview(String review) {
		this.review = review;
	}

	public Integer getProductID() {
		return productID;
	}

	public void setProductID(Integer productID) {
		this.productID = productID;
	}

	@Override
	public String toString() {
		return "Reviews [reviewId=" + reviewId + ", review=" + review + ", productID=" + productID + "]";
	}
	
	
	
	
	

}
