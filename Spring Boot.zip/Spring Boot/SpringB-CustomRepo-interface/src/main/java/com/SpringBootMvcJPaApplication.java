package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "com")//{"com.controller","com.model","com.repository","com.service"}
public class SpringBootMvcJPaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootMvcJPaApplication.class, args);
	}

}
