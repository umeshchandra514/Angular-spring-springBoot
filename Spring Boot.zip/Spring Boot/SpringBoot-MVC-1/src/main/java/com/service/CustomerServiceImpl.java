package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;


import com.model.CustomerDetails;
import com.repository.CustomerRepository;

public class CustomerServiceImpl implements CustomerService{

	@Autowired
	CustomerRepository customerRepository;
	
	
	
	
	
	@Override
	public boolean addCustomer(CustomerDetails customer) {
		return customerRepository.save(customer)!=null;
		
	}

	@Override
	public boolean updateCustomer(CustomerDetails customer) {
		return customerRepository.save(customer)!=null;
		
	}

	@Override
	public void deleteCustomer(int customerId) {
		 customerRepository.delete(customerId);
	}

	@Override
	public CustomerDetails findCustomer(int customerId) {
		return customerRepository.findOne(customerId);
		
	}


   @Override
	public boolean isCustomerExists(int customerId) {
		return false;//customerRepository.(customerId);
		
	}

	@Override
	public List<CustomerDetails> getCustomers() {
		return null;//return customerRepository.getCustomers();
	
	}
	
	@Override
	public List<CustomerDetails> findCustomers(String Mobile) {
		return customerRepository.findByMobile(Mobile);
		 
	
	}
	

}
