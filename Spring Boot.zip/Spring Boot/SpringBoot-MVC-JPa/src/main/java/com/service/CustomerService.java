package com.service;

import java.util.List;

import com.model.CustomerDetails;

public interface CustomerService {

	public CustomerDetails addCustomer(CustomerDetails customer);
	public boolean updateCustomer(CustomerDetails customer);
	public void deleteCustomer(int customerId);
	public CustomerDetails findCustomer(int customerId);
	public boolean isCustomerExists(int customerId);
	public List<CustomerDetails> getCustomers();
	public List<CustomerDetails> findCustomers(String Mobile);
	
}
