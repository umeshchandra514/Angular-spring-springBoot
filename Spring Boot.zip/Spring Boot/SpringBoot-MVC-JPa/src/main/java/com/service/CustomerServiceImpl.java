package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.CustomerDetails;
import com.repository.CustomerRepository;


@Service
public class CustomerServiceImpl implements CustomerService{

	@Autowired
	CustomerRepository customerRepository;
	
	
	
	
	
	@Override
	public CustomerDetails addCustomer(CustomerDetails customer) {
		//return customerRepository.save(customer)!=null;
		return customerRepository.save(customer);
		
		
	}

	@Override
	public boolean updateCustomer(CustomerDetails customer) {
		return customerRepository.save(customer)!=null;
		
	}

	@Override
	public void deleteCustomer(int customerId) {
		 customerRepository.deleteById(customerId);
	}

	/*
	 * @Override public CustomerDetails findCustomer(int customerId) { return
	 * customerRepository.findById(customerId);
	 * 
	 * }
	 */


   @Override
	public boolean isCustomerExists(int customerId) {
		return false;//customerRepository.(customerId);
		
	}

	@Override
	public List<CustomerDetails> getCustomers() {
		return null;//return customerRepository.getCustomers();
	
	}
	
	@Override
	public List<CustomerDetails> findCustomers(String Mobile) {
		return customerRepository.findByMobile(Mobile);
		 
	
	}

	@Override
	public CustomerDetails findCustomer(int customerId) {
		// TODO Auto-generated method stub
		return null;
	}
	

}
