package com.example.demo;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.model.MyModel;
import com.service.ProductService;

@RestController
@SpringBootApplication(scanBasePackages = "com")
public class Demo1Application {

	
	@Autowired
	ProductService productService;
	
	@RequestMapping("/")
	public List<MyModel> getProducts()
	{
	
		return productService.getProducts();
	}
	
	
	@RequestMapping(value="/getOne/{productId}/{id}", method=RequestMethod.GET)
	public MyModel getProductById(@PathVariable("productId")Integer productId,@PathVariable("id")Integer id)
	{
	
		return productService.getProductById(productId);
	}

	
	@RequestMapping(value="/save", method = RequestMethod.POST)
	public List<MyModel> save(@RequestBody MyModel product)
	{
		return productService.insert(product);
	
	}
	
	@RequestMapping(value="/update" , method = RequestMethod.PUT)
	public List<MyModel> update(@RequestBody MyModel product)
	{
		return productService.update(product);
				
	}
	
	
	@RequestMapping(value="/delete/{productId}" , method = RequestMethod.DELETE)
	public boolean delete(@PathVariable Integer productId)
	{
		return productService.delete(productId);
				
	}
	
	
	public static void main(String[] args) {
		SpringApplication.run(Demo1Application.class, args);
	}

}

