package com.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.model.MyModel;


@Service
public class ProductService {
	
	
	private List<MyModel> products= new ArrayList<MyModel>(Arrays.asList(
			new MyModel(1,"name",1,1),
			new MyModel(1,"name",1,1)));
	

	public List<MyModel> getProducts()
	{
		return products;
	}
	
	
	public MyModel getProductById(Integer productId)
	{
		return products.stream().filter(t -> t.getProductId() == (productId) ).findFirst().get();
	}


	public List<MyModel> insert(MyModel product) {
		
		products.add(product);
		return products;
		
	}


	public List<MyModel> update(MyModel product) {
		Integer productId = product.getProductId();
		for(int i=0;i< products.size();i++)
		{
			MyModel p = products.get(i);
			if(p.getProductId().equals(productId))
					{
						products.set(i, product);
					}
		}
		return products;
	}


	public boolean delete(Integer productId) {
		// TODO Auto-generated method stub
		return products.removeIf(t -> t.getProductId().equals(productId));
	}
	
	
}
