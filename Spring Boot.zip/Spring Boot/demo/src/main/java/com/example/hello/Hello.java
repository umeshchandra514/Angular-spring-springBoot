package com.example.hello;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Hello {
	
	@RequestMapping("/new")
	public String news()
	{
		return "new";
	}

	
	@Value("${credentials.username}")
	private String username;
	
	
	@Autowired
	MyCredentials credentialsConfiguraion;
	@RequestMapping("/credentials")
	public Map<String, String> display()
	{
		System.out.println(username);
		Map<String, String> data = new HashMap<String, String>();
		data.put("username",credentialsConfiguraion.getUsername());
		data.put("password",credentialsConfiguraion.getPassword());
		return data;
	}
	
}
