package com.example.service;
import com.example.model.MyModel;

import java.util.Arrays;
import java.util.List;

public class ProductService {
	
	
	private List<MyModel> products=Arrays.asList(new MyModel(1,"name",1,1));

}
