package com.acheron.property.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.acheron.property.model.Login;
import com.acheron.property.model.Property;
import com.acheron.property.model.SearchProperty;
import com.acheron.property.model.Wishlist;
//import com.acheron.property.model.SearchProperty;
import com.acheron.property.repository.AddRepository;
import com.acheron.property.repository.LoginRepository;
import com.acheron.property.repository.WishlistRepository;

@Service
public class PropertyServiceImpl implements PropertyService {

	@Autowired
	AddRepository addRepository;
	
	@Autowired
	HttpSession httpSession;
	
	@Autowired
	WishlistRepository wishlistRepository;
	
	@Autowired
	LoginRepository loginRepository;
	
	@Override
	public HttpStatus addProperty(Property addProperty) {
		System.out.println(addRepository.save(addProperty) != null);
		return HttpStatus.OK;
	}

	@Override
	public List<Property> getProperties() {
		return (List<Property>) addRepository.findAll();
		
	}

	@Override
	public HttpStatus updateProperty(Property updateProperty) {
		
		addRepository.save(updateProperty);
		return HttpStatus.OK;
	}

	//@SuppressWarnings("deprecation")
	@Override
	public List<Property> getPropertiesForInterests(String location,String rentSale,int priceFrom,int priceTo,String houseType) {
		//return addRepository.findAll(new PageRequest(0,3));
		return addRepository.searchByInterests(location,rentSale,houseType,priceFrom,priceTo);//
		//
	}

	public Property findByID(int propertyId)
	{
		return addRepository.findByPropertyId(propertyId);
	}

	@Override
	public void addToWishlist(Property property, Login login) {
		property.setWishlist(true);
		
		System.out.println(login);
		Wishlist wishlist = new Wishlist(0,login,property);
		System.out.println(wishlist);
		wishlistRepository.save(wishlist);
		//addRepository.save(property);
	}

	@Override
	public List<Property> getWishlist(String username) {
			List<Integer> propertyIDS = new ArrayList<Integer>(20);//wishlistRepository.findPropertyIdS(username);
			System.out.println(propertyIDS);
			return addRepository.findPropertyForIds(propertyIDS);	
		//return null;
	}
	
	
	@Override
	public boolean isPropertyExists(int propertyId) {
		return addRepository.existsById(propertyId);
		
	}
	
	@Override
	public void deleteProperty(int customerId) {
		addRepository.deleteById(customerId);
	}
	
	
	@Override
	public Optional<Login> getLogin(String username) {
		
		return loginRepository.findById(username);
		
	}
	
	
}
