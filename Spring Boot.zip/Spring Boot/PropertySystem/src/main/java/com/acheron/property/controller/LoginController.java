package com.acheron.property.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.acheron.property.model.Login;

import com.acheron.property.service.LoginService;

@RestController
@CrossOrigin(origins = {"http://localhost:4200"})
public class LoginController {
	
	@Autowired
	LoginService loginService;
	
	
	@Autowired
	HttpSession httpSession;
	
	@PostMapping("login")
	public ResponseEntity<Boolean> login(@RequestBody Login login)
	{
		boolean userAuthentication = loginService.userValidation(login) == null ? false : true;
		
		httpSession.setAttribute("username", login.getUsername());
		System.out.println(httpSession.getAttributeNames().toString());
		return new ResponseEntity<Boolean>(userAuthentication,HttpStatus.OK);
		
	}
}
