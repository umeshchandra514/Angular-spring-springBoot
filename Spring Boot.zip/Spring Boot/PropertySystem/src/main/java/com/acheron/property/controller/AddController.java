package com.acheron.property.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.acheron.property.model.Login;
import com.acheron.property.model.Property;
import com.acheron.property.model.SearchProperty;
//import com.acheron.property.model.SearchProperty;
import com.acheron.property.repository.AddRepository;
import com.acheron.property.service.PropertyService;

@RestController
@CrossOrigin(origins = {"http://localhost:4200"})
public class AddController {
	
	
	Map<String,String> propertyTypeItems= new HashMap<String, String>(){{ put("Apartment","Apartment"); 
		 put("Vilaa","Villa");}};
	
	
	
	@Autowired
	PropertyService propertyService;
	
	
	@Autowired
	HttpSession httpSession;
	
	//Viewing Properties By Interest
	@RequestMapping("viewresults/{location}/{rentsale}/{priceFrom}/{priceTo}/{houseType}")
	public ResponseEntity<List<Property>> viewResults(@PathVariable("location") String location,@PathVariable("rentsale") String rentsale,
													  @PathVariable("priceFrom") String priceFrom,@PathVariable("priceTo") String priceTo,
													  @PathVariable("houseType") String houseType)
	{
		List<Property> fetchedProperties=propertyService.getPropertiesForInterests(location,rentsale,Integer.parseInt(priceFrom),
																					Integer.parseInt(priceTo),houseType);
		
		return new ResponseEntity<List<Property>>(fetchedProperties,HttpStatus.OK);//.getContent()
	}
	
	
	
	
	
	//---------------------WIshlist------------
	
	@GetMapping("wishlist/{propertyId}/{username}")
	public ResponseEntity<List<Property>> wishlist(@PathVariable("propertyId")String propertyId,@PathVariable("username")String username)
	{
		
		Property property = propertyService.findByID(Integer.parseInt(propertyId));
		
		Optional<Login> login = propertyService.getLogin(username);
		List<Property> wishlist;
		if(login.isPresent())
		{
			propertyService.addToWishlist(property,login.get());
		}
		wishlist=propertyService.getWishlist(username);
		return new ResponseEntity<List<Property>>(wishlist,HttpStatus.OK);
		
	}
	
	
	@GetMapping("wishlist/{username}")
	public ResponseEntity<List<Property>> wishlist( @PathVariable("username") String username)
	{
		username = (String) httpSession.getAttribute("username");
		List<Property> wishlist=propertyService.getWishlist(username);
		return new ResponseEntity<List<Property>>(wishlist,HttpStatus.OK);
		
	}
	
	
	//------------------------Wishlist-----------------
	
	
	
	//-----------Property(ADDING,DELETING,UPDATING)------------
	
	@PostMapping("property")
	public ResponseEntity<Property> add(@RequestBody Property addProperty)
	{
		System.out.println(addProperty);
		HttpStatus status = propertyService.addProperty(addProperty);
		
		return new ResponseEntity<Property>(addProperty,status);
		//return null;
	}
	
	
	@PutMapping("property")
	public ResponseEntity<Property> update(@RequestBody Property addProperty)
	{
		System.out.println(addProperty);
		HttpStatus status = propertyService.updateProperty(addProperty);
		
		return new ResponseEntity<Property>(addProperty,status);
		//return null;
	}
	
	
	@GetMapping("property")
	public ResponseEntity<List<Property>> get()
	{
		
		
		//view.addObject("typeItems", propertyTypeItems );
		List<Property> addproperty =  propertyService.getProperties();
		//view.setViewName("addForm");
		
		return new ResponseEntity<List<Property>>(addproperty,HttpStatus.OK) 	;
		
	}
	
	@DeleteMapping("property/{propertyId}")
	public void delete(@PathVariable("propertyId") Integer propertyId) {
		propertyService.deleteProperty(propertyId);
	}
}
