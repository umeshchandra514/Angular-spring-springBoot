package com.acheron.property.model;

import java.util.Optional;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;

@Entity
public class Wishlist {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int wishlistId;
	
	@OneToOne
	@JoinColumn(name="username")
	private Login login;
	
	@OneToOne
	@JoinColumn(name="propertyId")
	private Property property;

	
	
	public Wishlist(int wishlistId, Login login, Property property) {
		super();
		this.wishlistId = wishlistId;
		this.login = login;
		this.property = property;
	}






	@Override
	public String toString() {
		return "Wishlist [wishlistId=" + wishlistId + ", login=" + login + ", property=" + property + "]";
	}

	
	
	
	
	
}
