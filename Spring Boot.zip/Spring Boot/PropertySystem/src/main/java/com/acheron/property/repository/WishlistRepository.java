package com.acheron.property.repository;

import java.util.List;


import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;//,PropertySearchRepository
import org.springframework.data.repository.query.Param;

import com.acheron.property.model.Wishlist;

public interface WishlistRepository extends CrudRepository<Wishlist, Integer> {

	@Query(value = "select property_id from wishlist where username = :username",nativeQuery = true)
	List<Integer> findPropertyIdS(@Param("username")String username);

}
 //  //