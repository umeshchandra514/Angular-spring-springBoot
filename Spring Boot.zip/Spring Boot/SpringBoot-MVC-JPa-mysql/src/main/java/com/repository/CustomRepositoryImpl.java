package com.repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.model.Reviews;

public class CustomRepositoryImpl implements CustomRepositoryI {

	@PersistenceContext
	EntityManager em;
	
	
	@Override
	public void refresh() { //Reviews reviews
		//em.refresh(); //reviews
		
	}

}
