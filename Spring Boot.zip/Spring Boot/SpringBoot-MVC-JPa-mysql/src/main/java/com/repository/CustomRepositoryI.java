package com.repository;

import com.model.Reviews;

public interface CustomRepositoryI {

	void refresh();//Reviews reviews
}
