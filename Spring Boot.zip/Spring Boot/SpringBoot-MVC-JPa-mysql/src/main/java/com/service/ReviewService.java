package com.service;

import java.util.List;

import com.model.Reviews;

public interface ReviewService {

	

	void addReview(Reviews review);

	List<Reviews> getReviewByPId(Integer productId);

	List<Reviews> getReviews();

	Reviews getReviewByPIdRId(Integer productId, Integer reviewId);

	List<Reviews> getReviewsOfPid(Integer productId, Integer count);

	void refresh();

}
