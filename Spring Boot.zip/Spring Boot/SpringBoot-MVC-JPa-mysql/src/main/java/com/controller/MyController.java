package com.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.model.CustomerDetails;
import com.service.CustomerService;



@RestController
@CrossOrigin(origins = {"http://localhost:4200"},methods = { RequestMethod.GET,RequestMethod.POST,RequestMethod.DELETE,RequestMethod.PUT })
public class MyController {
	
	@Autowired
	CustomerService customerService;

	@RequestMapping("/umesh")
	public String getUmesh()
	{
		return "hello";
	}
	
	@RequestMapping(value="/product",method = RequestMethod.POST)
	public CustomerDetails doSave(@RequestBody CustomerDetails customer)
	{
		CustomerDetails details = customerService.addCustomer(customer);
		System.out.println(details);
		return details;
		//return customer;//customerService.addCustomer(customer);
	
	}
	
	@RequestMapping(value="/product", method = RequestMethod.GET)
	public List<CustomerDetails> doGet()
	{
		System.out.println(customerService.getCustomers());
		return customerService.getCustomers();
	}
	
	@RequestMapping(value="/productById/{productId}",method = RequestMethod.DELETE)
	public ResponseEntity<Integer> doDelete(@PathVariable
			("productId") Integer productId) {
		HttpStatus status = customerService.deleteCustomer(productId);
		return new ResponseEntity<Integer>(status);
	}
	
	@RequestMapping(value="/product",method = RequestMethod.PUT)
	public ResponseEntity<Integer> doUpdate(@RequestBody CustomerDetails customer) {
		HttpStatus status = customerService.updateCustomer(customer);
		
		return new ResponseEntity<Integer>(status);
	}
	
	@RequestMapping(value="productById/{productId}" ,method = RequestMethod.GET)
	public ResponseEntity<Optional<CustomerDetails>> doGetById(@PathVariable("productId")Integer productId) {
		//return customerService.findCustomer(productId);
		Optional<CustomerDetails> customer = customerService.findCustomer(productId);//Integer.parseInt(

		if(customer.isPresent()) {
			return new ResponseEntity<Optional<CustomerDetails>>(customer,HttpStatus.OK);
		}
		else
		{
			return new ResponseEntity<Optional<CustomerDetails>>(customer,HttpStatus.NO_CONTENT);
		}
		
	}
	
}
