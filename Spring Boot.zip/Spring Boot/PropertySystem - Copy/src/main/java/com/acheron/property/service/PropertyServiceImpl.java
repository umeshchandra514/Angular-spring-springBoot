package com.acheron.property.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.acheron.property.model.Property;
import com.acheron.property.model.SearchProperty;
//import com.acheron.property.model.SearchProperty;
import com.acheron.property.repository.AddRepository;

@Service
public class PropertyServiceImpl implements PropertyService {

	@Autowired
	AddRepository addRepository;
	@Override
	public HttpStatus addProperty(Property addProperty) {
		System.out.println(addRepository.save(addProperty) != null);
		return HttpStatus.OK;
	}

	@Override
	public List<Property> getProperties() {
		return (List<Property>) addRepository.findAll();
		
	}

	@Override
	public HttpStatus updateProperty(Property updateProperty) {
		
		addRepository.save(updateProperty);
		return HttpStatus.OK;
	}

	@Override
	public List<Property> getPropertiesForInterests(String location,String rentSale,int priceFrom,int priceTo,String houseType) {
		return addRepository.searchByInterests(location,rentSale,houseType,priceFrom,priceTo);//
		//
	}

	public Property findByID(int propertyId)
	{
		return addRepository.findByPropertyId(propertyId);
	}

	@Override
	public void addToWishlist(Property property) {
		property.setWishlist(true);
		addRepository.save(property);
	}

	@Override
	public List<Property> getWishlist() {
			return (List<Property>) addRepository.findByWishlist(true);
		
	}
	
	
	@Override
	public boolean isPropertyExists(int propertyId) {
		return addRepository.existsById(propertyId);
		
	}
	
	@Override
	public void deleteProperty(int customerId) {
		addRepository.deleteById(customerId);
	}
}
