package com.acheron.property.service;

import java.util.List;

import org.springframework.http.HttpStatus;

import com.acheron.property.model.*;


public interface PropertyService {
	
	
	public HttpStatus addProperty(Property addProperty);
	
	public List<Property> getProperties();
	
	public HttpStatus updateProperty(Property updateProperty);
		
	public Property findByID(int propertyId);

	public void addToWishlist(Property property);

	public List<Property> getWishlist();

	boolean isPropertyExists(int customerId);

	void deleteProperty(int customerId);

	public List<Property> getPropertiesForInterests(String location, String rentsale, int parseFrom, int parseTo,
			String houseType);

}
