package com.acheron.property.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;//,PropertySearchRepository

import com.acheron.property.model.Property;

public interface AddRepository extends CrudRepository<Property, Integer> {

	//Get Properties for based on user interests
	@Query(value="select * from property where property_location = ?1 AND property_sale_rent = ?2 AND property_type = ?3 AND property_price >= ?4 AND property_price <= ?5",nativeQuery=true)// AND propertyPrice <= ?5
	List<Property> searchByInterests(String location, String salerent,String type, int minimum,int maximum);//, int minimum, int maximum, String type

	Property findByPropertyId(int PropertyId);
	List<Property> findByWishlist(boolean wishlist);
}
 //  